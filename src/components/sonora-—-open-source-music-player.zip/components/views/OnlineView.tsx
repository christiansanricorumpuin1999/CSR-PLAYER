'use client';

import React, { useState } from 'react';
import {
  Globe2,
  Search,
  Play,
  ListPlus,
  ExternalLink,
  AlertCircle,
  CheckCircle2,
  Youtube,
  Radio,
  FileAudio,
  ShieldAlert,
} from 'lucide-react';
import { resolveMediaUrl } from '@/lib/resolver';
import { ResolvedMedia, Track } from '@/lib/types';
import { useAudioPlayer } from '@/lib/audioPlayerStore';

export function OnlineView() {
  const { playTrack, addToQueue } = useAudioPlayer();
  const [urlInput, setUrlInput] = useState('');
  const [isResolving, setIsResolving] = useState(false);
  const [resolved, setResolved] = useState<ResolvedMedia | null>(null);

  const handleResolve = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!urlInput.trim() || isResolving) return;

    setIsResolving(true);
    setResolved(null);
    try {
      const result = await resolveMediaUrl(urlInput.trim());
      setResolved(result);
    } catch (err: any) {
      setResolved({
        provider: 'unknown',
        canonicalUrl: urlInput,
        playbackType: 'unsupported',
        playable: false,
        reason: err?.message || 'Resolution failed.',
      });
    } finally {
      setIsResolving(false);
    }
  };

  const handlePlayResolved = () => {
    if (!resolved || !resolved.playable) return;

    const track: Track = {
      id: `online_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: resolved.title || 'Online Track',
      artist: resolved.artist || 'Online Provider',
      artworkUrl: resolved.artworkUrl,
      source: resolved.provider === 'youtube' ? 'youtube-embed' : 'spotify-embed',
      sourceUrl: resolved.embedUrl || resolved.canonicalUrl,
      addedAt: Date.now(),
      isFavorite: false,
    };

    playTrack(track);
  };

  const handleQueueResolved = () => {
    if (!resolved || !resolved.playable) return;

    const track: Track = {
      id: `online_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: resolved.title || 'Online Track',
      artist: resolved.artist || 'Online Provider',
      artworkUrl: resolved.artworkUrl,
      source: resolved.provider === 'youtube' ? 'youtube-embed' : 'spotify-embed',
      sourceUrl: resolved.embedUrl || resolved.canonicalUrl,
      addedAt: Date.now(),
      isFavorite: false,
    };

    addToQueue(track);
  };

  return (
    <div className="space-y-6 pb-24 md:pb-12 animate-in fade-in duration-200">
      <div>
        <h1 className="text-2xl font-black text-[#20252D]">Online Link Resolver</h1>
        <p className="text-xs text-[#777777]">
          Resolves music links using verified, official embeds and APIs. No audio ripping or stream circumvention.
        </p>
      </div>

      {/* Input Resolver Form */}
      <div className="p-6 bg-[#FFFEFA] border-2 border-[#20252D] rounded-3xl shadow-[4px_4px_0px_#20252D]">
        <form onSubmit={handleResolve} className="space-y-3">
          <label htmlFor="music-url-input" className="block text-xs font-bold uppercase tracking-wider text-[#777777]">
            Paste a music link (YouTube, Spotify, MetroList, or Direct Audio)
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              id="music-url-input"
              type="url"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=... or https://open.spotify.com/track/..."
              className="flex-1 px-4 py-2.5 bg-[#F5F2E8] border-2 border-[#20252D] rounded-2xl text-xs sm:text-sm font-medium text-[#20252D] placeholder-[#777777] focus:outline-hidden"
              required
            />
            <button
              type="submit"
              disabled={!urlInput.trim() || isResolving}
              className="px-6 py-2.5 bg-[#354BCB] text-white text-xs sm:text-sm font-bold rounded-2xl border-2 border-[#20252D] shadow-[2px_2px_0px_#20252D] hover:bg-[#2e41b0] disabled:opacity-50 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              {isResolving ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Resolving...</span>
                </>
              ) : (
                <>
                  <Globe2 className="w-4 h-4" />
                  <span>Resolve Link</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Resolved Card Output */}
        {resolved && (
          <div className="mt-6 p-4 rounded-2xl border-2 border-[#20252D] bg-[#F5F2E8] shadow-[2px_2px_0px_#20252D]">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-[#20252D]/10">
              <div className="flex items-center gap-2">
                {resolved.playable ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-[#A8E6D8] border border-[#20252D] text-[#20252D]">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Playable ({resolved.provider.toUpperCase()})
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase bg-[#F47768]/20 border border-[#F47768] text-[#20252D]">
                    <ShieldAlert className="w-3.5 h-3.5 text-[#F47768]" />
                    {resolved.playbackType === 'external-only' ? 'External Link Only' : 'Unsupported Direct Playback'}
                  </span>
                )}
              </div>

              <a
                href={resolved.canonicalUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-bold text-[#354BCB] hover:underline"
              >
                <span>Open in {resolved.provider.toUpperCase()}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="mt-3 flex items-start gap-4">
              {resolved.artworkUrl ? (
                <img
                  src={resolved.artworkUrl}
                  alt={resolved.title || 'Artwork'}
                  className="w-16 h-16 rounded-xl border border-[#20252D] object-cover shrink-0"
                />
              ) : (
                <div className="w-16 h-16 rounded-xl border border-[#20252D] bg-[#FFFEFA] flex items-center justify-center text-xs font-bold shrink-0">
                  {resolved.provider.slice(0, 3).toUpperCase()}
                </div>
              )}

              <div className="min-w-0 flex-1">
                <h4 className="font-extrabold text-sm text-[#20252D] truncate">
                  {resolved.title || resolved.canonicalUrl}
                </h4>
                <p className="text-xs text-[#777777] mt-0.5">
                  {resolved.artist || 'Online Provider'}
                </p>

                {resolved.reason && (
                  <p className="mt-2 text-xs text-[#20252D] bg-[#FFFEFA] p-2.5 rounded-xl border border-[#20252D]/30 leading-relaxed">
                    <strong>Notice:</strong> {resolved.reason}
                  </p>
                )}
              </div>
            </div>

            {resolved.playable && (
              <div className="mt-4 flex items-center gap-2 pt-2 border-t border-[#20252D]/10">
                <button
                  type="button"
                  onClick={handlePlayResolved}
                  className="px-4 py-2 bg-[#354BCB] text-white text-xs font-bold rounded-xl border border-[#20252D] shadow-[2px_2px_0px_#20252D] hover:bg-[#2e41b0] flex items-center gap-1.5 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Play Now</span>
                </button>
                <button
                  type="button"
                  onClick={handleQueueResolved}
                  className="px-4 py-2 bg-[#FFFEFA] text-[#20252D] text-xs font-bold rounded-xl border border-[#20252D] hover:bg-[#F5F2E8] flex items-center gap-1.5 cursor-pointer"
                >
                  <ListPlus className="w-3.5 h-3.5 text-[#354BCB]" />
                  <span>Add to Queue</span>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Provider Policies Guide Cards */}
      <div>
        <h3 className="text-sm font-extrabold uppercase tracking-wider text-[#777777] mb-3">
          Supported Integrations & Policies
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* YouTube Policy */}
          <div className="p-4 bg-[#FFFEFA] border-2 border-[#20252D] rounded-2xl shadow-[3px_3px_0px_#20252D]">
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-[#F47768] text-white">
                <Youtube className="w-4 h-4" />
              </span>
              <h4 className="font-extrabold text-xs text-[#20252D]">YouTube</h4>
            </div>
            <p className="text-[11px] text-[#777777] leading-relaxed">
              Uses the official YouTube IFrame Player embed. Does not rip, download, or bypass restrictions. Videos with disabled embedding can be opened in YouTube.
            </p>
          </div>

          {/* Spotify Policy */}
          <div className="p-4 bg-[#FFFEFA] border-2 border-[#20252D] rounded-2xl shadow-[3px_3px_0px_#20252D]">
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-[#1DB954] text-white">
                <Radio className="w-4 h-4" />
              </span>
              <h4 className="font-extrabold text-xs text-[#20252D]">Spotify</h4>
            </div>
            <p className="text-[11px] text-[#777777] leading-relaxed">
              Uses official Spotify oEmbed & Embed players. Direct audio extraction is prohibited by policy. Preview playback is available via the official widget.
            </p>
          </div>

          {/* MetroList Policy */}
          <div className="p-4 bg-[#FFFEFA] border-2 border-[#20252D] rounded-2xl shadow-[3px_3px_0px_#20252D]">
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1.5 rounded-lg bg-[#B9A6F2] text-[#20252D]">
                <Globe2 className="w-4 h-4" />
              </span>
              <h4 className="font-extrabold text-xs text-[#20252D]">MetroList</h4>
            </div>
            <p className="text-[11px] text-[#777777] leading-relaxed">
              Treated as external third-party service without public playback APIs. Direct audio playback is unsupported; open links directly in MetroList.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
