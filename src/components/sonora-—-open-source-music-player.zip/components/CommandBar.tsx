'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, Send, CheckCircle2, AlertCircle, HelpCircle, X } from 'lucide-react';
import { useAudioPlayer } from '@/lib/audioPlayerStore';
import { COMMAND_HELP_LIST } from '@/lib/commandParser';
import { CommandResult } from '@/lib/types';

export function CommandBar() {
  const { executeCommand } = useAudioPlayer();
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<CommandResult | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close suggestions on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    setIsLoading(true);
    setShowSuggestions(false);
    try {
      const res = await executeCommand(input.trim());
      setResult(res);
      if (res.success && res.action !== 'help') {
        setInput('');
      }
    } catch (err: any) {
      setResult({
        success: false,
        action: 'unknown',
        message: err?.message || 'Failed to process command.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectSuggestion = (cmd: string) => {
    setInput(cmd);
    setShowSuggestions(false);
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-xl">
      <form onSubmit={handleSubmit} className="relative flex items-center">
        <div className="absolute left-3.5 flex items-center pointer-events-none text-[#777777]">
          <Terminal className="w-4 h-4 text-[#354BCB]" />
        </div>

        <input
          type="text"
          value={input}
          onChange={(e) => {
            setInput(e.target.value);
            setShowSuggestions(e.target.value.startsWith('/'));
          }}
          onFocus={() => {
            if (input.startsWith('/') || input === '') {
              setShowSuggestions(true);
            }
          }}
          placeholder="Try /play <music URL> or /help"
          className="w-full pl-10 pr-24 py-2.5 bg-[#FFFEFA] border-2 border-[#20252D] rounded-2xl text-xs md:text-sm font-medium text-[#20252D] placeholder-[#777777] shadow-[2px_2px_0px_#20252D] focus:outline-hidden focus:ring-2 focus:ring-[#354BCB]/30 transition-all"
        />

        <div className="absolute right-2 flex items-center gap-1">
          <button
            type="button"
            onClick={() => setShowSuggestions((prev) => !prev)}
            title="Command list"
            aria-label="Show available commands"
            className="p-1 text-[#777777] hover:text-[#20252D] rounded-lg hover:bg-[#F5F2E8] transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            aria-label="Send command"
            className="px-2.5 py-1 bg-[#354BCB] text-white rounded-xl text-xs font-bold border border-[#20252D] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#2e41b0] transition-colors flex items-center gap-1 cursor-pointer"
          >
            {isLoading ? (
              <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </form>

      {/* Auto-suggest dropdown */}
      {showSuggestions && (
        <div className="absolute top-full left-0 right-0 mt-2 z-40 bg-[#FFFEFA] border-2 border-[#20252D] rounded-2xl p-2 shadow-[4px_4px_0px_#20252D] max-h-60 overflow-y-auto">
          <div className="px-2 py-1 text-[11px] font-bold uppercase tracking-wider text-[#777777] border-b border-[#F5F2E8] mb-1">
            Discord-Style Music Commands
          </div>
          {COMMAND_HELP_LIST.map((item) => (
            <button
              key={item.command}
              type="button"
              onClick={() => handleSelectSuggestion(item.command.split(' ')[0] + ' ')}
              className="w-full text-left px-2.5 py-1.5 rounded-xl hover:bg-[#F5F2E8] flex items-center justify-between group transition-colors cursor-pointer"
            >
              <span className="font-mono text-xs font-bold text-[#354BCB] group-hover:underline">
                {item.command}
              </span>
              <span className="text-[11px] text-[#777777]">{item.desc}</span>
            </button>
          ))}
        </div>
      )}

      {/* Real Execution Result Banner */}
      {result && (
        <div
          className={`absolute top-full left-0 right-0 mt-2 z-30 p-3 rounded-2xl border-2 border-[#20252D] shadow-[3px_3px_0px_#20252D] flex items-start gap-2 text-xs font-medium animate-in fade-in slide-in-from-top-1 ${
            result.success ? 'bg-[#FFFEFA] text-[#20252D]' : 'bg-[#F47768]/15 text-[#20252D]'
          }`}
        >
          {result.success ? (
            <CheckCircle2 className="w-4 h-4 text-[#354BCB] shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-[#F47768] shrink-0 mt-0.5" />
          )}
          <div className="flex-1 whitespace-pre-line leading-relaxed font-mono">
            {result.message}
          </div>
          <button
            type="button"
            onClick={() => setResult(null)}
            aria-label="Dismiss feedback message"
            className="text-[#777777] hover:text-[#20252D] p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
