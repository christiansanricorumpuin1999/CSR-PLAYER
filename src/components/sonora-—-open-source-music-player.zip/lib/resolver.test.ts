import test from 'node:test';
import assert from 'node:assert/strict';
import { extractYouTubeId, extractSpotifyTrackInfo, isDirectAudioUrl, resolveMediaUrl } from './resolver';

test('extractYouTubeId parses standard watch URL', () => {
  const id = extractYouTubeId('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  assert.equal(id, 'dQw4w9WgXcQ');
});

test('extractYouTubeId parses youtu.be short URL', () => {
  const id = extractYouTubeId('https://youtu.be/dQw4w9WgXcQ?t=42');
  assert.equal(id, 'dQw4w9WgXcQ');
});

test('extractYouTubeId parses shorts and embed URLs', () => {
  assert.equal(extractYouTubeId('https://youtube.com/shorts/abcdef12345'), 'abcdef12345');
  assert.equal(extractYouTubeId('https://www.youtube.com/embed/test1234'), 'test1234');
});

test('extractSpotifyTrackInfo parses track, album, and playlist URLs', () => {
  const track = extractSpotifyTrackInfo('https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT?si=abc');
  assert.deepEqual(track, { type: 'track', id: '4cOdK2wGLETKBW3PvgPWqT' });

  const album = extractSpotifyTrackInfo('https://open.spotify.com/album/1DFixLWuPkv3KT3TnV35m3');
  assert.deepEqual(album, { type: 'album', id: '1DFixLWuPkv3KT3TnV35m3' });
});

test('isDirectAudioUrl identifies audio file extensions', () => {
  assert.equal(isDirectAudioUrl('https://example.com/audio/song.mp3'), true);
  assert.equal(isDirectAudioUrl('https://example.com/audio/song.wav'), true);
  assert.equal(isDirectAudioUrl('https://example.com/audio/song.flac'), true);
  assert.equal(isDirectAudioUrl('https://example.com/page.html'), false);
});

test('resolveMediaUrl correctly categorizes MetroList as unsupported direct playback', async () => {
  const res = await resolveMediaUrl('https://metrolist.app/track/123');
  assert.equal(res.provider, 'metrolist');
  assert.equal(res.playable, false);
  assert.equal(res.playbackType, 'external-only');
  assert.ok(res.reason?.includes('MetroList does not provide'));
});

test('resolveMediaUrl rejects invalid protocol', async () => {
  const res = await resolveMediaUrl('ftp://example.com/music');
  assert.equal(res.playable, false);
  assert.equal(res.playbackType, 'unsupported');
});
