import { ResolvedMedia } from './types';

export function extractYouTubeId(urlStr: string): string | null {
  try {
    const url = new URL(urlStr);
    const hostname = url.hostname.replace(/^www\./, '').toLowerCase();

    if (hostname === 'youtube.com' || hostname === 'm.youtube.com') {
      if (url.pathname === '/watch') {
        return url.searchParams.get('v');
      }
      if (url.pathname.startsWith('/shorts/')) {
        return url.pathname.split('/shorts/')[1]?.split(/[?&/]/)[0] || null;
      }
      if (url.pathname.startsWith('/embed/')) {
        return url.pathname.split('/embed/')[1]?.split(/[?&/]/)[0] || null;
      }
    } else if (hostname === 'youtu.be') {
      return url.pathname.slice(1).split(/[?&/]/)[0] || null;
    }
  } catch {
    return null;
  }
  return null;
}

export function extractSpotifyTrackInfo(urlStr: string): { type: string; id: string } | null {
  try {
    const url = new URL(urlStr);
    const hostname = url.hostname.replace(/^www\./, '').toLowerCase();

    if (hostname === 'open.spotify.com') {
      const parts = url.pathname.split('/').filter(Boolean);
      // Format: /track/{id}, /album/{id}, /playlist/{id}
      if (parts.length >= 2) {
        const type = parts[0];
        const id = parts[1].split('?')[0];
        if (['track', 'album', 'playlist', 'episode'].includes(type)) {
          return { type, id };
        }
      }
    }
  } catch {
    return null;
  }
  return null;
}

export function isDirectAudioUrl(urlStr: string): boolean {
  try {
    const url = new URL(urlStr);
    const path = url.pathname.toLowerCase();
    return (
      path.endsWith('.mp3') ||
      path.endsWith('.wav') ||
      path.endsWith('.ogg') ||
      path.endsWith('.m4a') ||
      path.endsWith('.aac') ||
      path.endsWith('.flac')
    );
  } catch {
    return false;
  }
}

export async function resolveMediaUrl(rawUrl: string): Promise<ResolvedMedia> {
  let validUrl: URL;
  try {
    validUrl = new URL(rawUrl.trim());
    if (validUrl.protocol !== 'http:' && validUrl.protocol !== 'https:') {
      return {
        provider: 'unknown',
        canonicalUrl: rawUrl,
        playbackType: 'unsupported',
        playable: false,
        reason: 'Only HTTP and HTTPS URLs are supported.',
      };
    }
  } catch {
    return {
      provider: 'unknown',
      canonicalUrl: rawUrl,
      playbackType: 'unsupported',
      playable: false,
      reason: 'Invalid URL format.',
    };
  }

  const hostname = validUrl.hostname.replace(/^www\./, '').toLowerCase();

  // 1. YouTube
  const ytId = extractYouTubeId(validUrl.toString());
  if (ytId) {
    let title = `YouTube Track (${ytId})`;
    let artist = 'YouTube';
    let artworkUrl = `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`;

    // Try fetching official oEmbed title
    try {
      if (typeof window !== 'undefined') {
        const oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(
          validUrl.toString()
        )}&format=json`;
        const res = await fetch(oembedUrl);
        if (res.ok) {
          const data = await res.json();
          if (data.title) title = data.title;
          if (data.author_name) artist = data.author_name;
          if (data.thumbnail_url) artworkUrl = data.thumbnail_url;
        }
      }
    } catch {
      // Fallback to default metadata
    }

    return {
      provider: 'youtube',
      title,
      artist,
      artworkUrl,
      canonicalUrl: `https://www.youtube.com/watch?v=${ytId}`,
      embedId: ytId,
      embedUrl: `https://www.youtube-nocookie.com/embed/${ytId}?enablejsapi=1&autoplay=1`,
      playbackType: 'embed',
      playable: true,
    };
  }

  // 2. Spotify
  const spotifyInfo = extractSpotifyTrackInfo(validUrl.toString());
  if (spotifyInfo) {
    let title = `Spotify ${spotifyInfo.type.toUpperCase()}`;
    let artist = 'Spotify';
    let artworkUrl = '';

    // Try fetching official Spotify oEmbed
    try {
      if (typeof window !== 'undefined') {
        const oembedUrl = `https://open.spotify.com/oembed?url=${encodeURIComponent(
          validUrl.toString()
        )}`;
        const res = await fetch(oembedUrl);
        if (res.ok) {
          const data = await res.json();
          if (data.title) title = data.title;
          if (data.thumbnail_url) artworkUrl = data.thumbnail_url;
        }
      }
    } catch {
      // Fallback
    }

    return {
      provider: 'spotify',
      title,
      artist,
      artworkUrl,
      canonicalUrl: validUrl.toString(),
      embedId: spotifyInfo.id,
      embedUrl: `https://open.spotify.com/embed/${spotifyInfo.type}/${spotifyInfo.id}`,
      playbackType: 'embed',
      playable: true,
    };
  }

  // 3. MetroList / Metrolist
  if (hostname.includes('metrolist') || validUrl.toString().toLowerCase().includes('metrolist')) {
    return {
      provider: 'metrolist',
      title: 'MetroList Media Link',
      artist: 'MetroList',
      canonicalUrl: validUrl.toString(),
      playbackType: 'external-only',
      playable: false,
      reason:
        'MetroList does not provide a public, documented Web Playback API or embed stream. Direct audio playback is unsupported to honor platform terms. You can open the track directly in MetroList.',
    };
  }

  // 4. Direct Audio URL
  if (isDirectAudioUrl(validUrl.toString())) {
    const filename = validUrl.pathname.split('/').pop() || 'Remote Audio Track';
    return {
      provider: 'unknown',
      title: decodeURIComponent(filename),
      artist: validUrl.hostname,
      canonicalUrl: validUrl.toString(),
      playbackType: 'embed',
      playable: true,
    };
  }

  // 5. Unsupported generic URL
  return {
    provider: 'unknown',
    canonicalUrl: validUrl.toString(),
    playbackType: 'unsupported',
    playable: false,
    reason: `Direct playback for domain "${hostname}" is not officially supported. SONORA uses only documented provider APIs and embeds.`,
  };
}
