export type TrackSource =
  | 'local'
  | 'youtube-embed'
  | 'spotify-embed'
  | 'external';

export interface Track {
  id: string;
  title: string;
  artist?: string;
  album?: string;
  duration?: number; // in seconds
  artworkUrl?: string; // object URL or external URL
  artworkBlob?: Blob;
  source: TrackSource;
  sourceUrl?: string;
  localBlob?: Blob;
  mimeType?: string;
  fileName?: string;
  fileSize?: number;
  folderPath?: string;
  addedAt: number;
  lastPlayedAt?: number;
  isFavorite: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
  updatedAt: number;
}

export interface QueueItem {
  id: string;
  track: Track;
  status: 'resolving' | 'ready' | 'playing' | 'failed';
  error?: string;
}

export type RepeatMode = 'off' | 'one' | 'all';

export type PlaybackStatus = 'idle' | 'loading' | 'playing' | 'paused' | 'error';

export interface ResolvedMedia {
  provider: 'youtube' | 'spotify' | 'metrolist' | 'unknown' | 'local';
  title?: string;
  artist?: string;
  artworkUrl?: string;
  canonicalUrl: string;
  embedId?: string;
  embedUrl?: string;
  playbackType: 'embed' | 'sdk' | 'external-only' | 'unsupported';
  playable: boolean;
  reason?: string;
}

export interface CommandResult {
  success: boolean;
  action:
    | 'play'
    | 'add'
    | 'pause'
    | 'resume'
    | 'skip'
    | 'back'
    | 'clear'
    | 'shuffle'
    | 'repeat'
    | 'help'
    | 'unknown';
  payload?: any;
  message: string;
}
