'use client';

import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { CommandResult, QueueItem, RepeatMode, Track } from './types';
import { parseCommand, COMMAND_HELP_LIST } from './commandParser';
import { resolveMediaUrl } from './resolver';
import { getAllTracks, recordHistory, toggleFavorite as dbToggleFavorite } from './db';

interface AudioPlayerContextType {
  currentTrack: Track | null;
  status: 'idle' | 'loading' | 'playing' | 'paused' | 'error';
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  repeatMode: RepeatMode;
  isShuffle: boolean;
  queue: QueueItem[];
  queueIndex: number;
  errorMessage?: string;
  activeProvider: 'local' | 'youtube' | 'spotify' | 'external' | null;
  embedUrl?: string;
  isFullPlayerOpen: boolean;
  isOnline: boolean;

  playTrack: (track: Track, newQueue?: Track[]) => Promise<void>;
  togglePlayPause: () => void;
  pause: () => void;
  resume: () => void;
  seek: (seconds: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  skipNext: () => void;
  skipPrevious: () => void;
  toggleShuffle: () => void;
  setRepeatMode: (mode: RepeatMode) => void;
  addToQueue: (track: Track) => void;
  removeFromQueue: (queueItemId: string) => void;
  reorderQueue: (fromIndex: number, toIndex: number) => void;
  clearQueue: () => void;
  executeCommand: (cmdStr: string) => Promise<CommandResult>;
  openFullPlayer: () => void;
  closeFullPlayer: () => void;
  toggleFavorite: (trackId: string) => Promise<void>;
  handleTracksRemoved: (trackIds: string[]) => void;
}

const AudioPlayerContext = createContext<AudioPlayerContextType | null>(null);

export function AudioPlayerProvider({ children }: { children: React.ReactNode }) {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [status, setStatus] = useState<'idle' | 'loading' | 'playing' | 'paused' | 'error'>('idle');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.85);
  const [isMuted, setIsMuted] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
  const [isShuffle, setIsShuffle] = useState(false);
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [queueIndex, setQueueIndex] = useState(-1);
  const [errorMessage, setErrorMessage] = useState<string | undefined>();
  const [activeProvider, setActiveProvider] = useState<'local' | 'youtube' | 'spotify' | 'external' | null>(null);
  const [embedUrl, setEmbedUrl] = useState<string | undefined>();
  const [isFullPlayerOpen, setIsFullPlayerOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(true);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentObjectUrlRef = useRef<string | null>(null);

  // Online / Offline listener
  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIsOnline(navigator.onLine);
      const handleOnline = () => setIsOnline(true);
      const handleOffline = () => setIsOnline(false);
      window.addEventListener('online', handleOnline);
      window.addEventListener('offline', handleOffline);
      return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
      };
    }
  }, []);

  // Initialize native HTMLAudioElement
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const audio = new Audio();
    audio.preload = 'auto';
    audioRef.current = audio;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const onLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
      setStatus('playing');
    };

    const onPlay = () => setStatus('playing');
    const onPause = () => {
      if (status !== 'loading' && status !== 'error') {
        setStatus('paused');
      }
    };

    const onError = () => {
      setStatus('error');
      setErrorMessage(audio.error?.message || 'Failed to decode or play audio file.');
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('error', onError);

    return () => {
      audio.pause();
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('error', onError);
      if (currentObjectUrlRef.current) {
        URL.revokeObjectURL(currentObjectUrlRef.current);
      }
    };
  }, []);

  // Update MediaSession
  const updateMediaSession = useCallback((track: Track) => {
    if (typeof window === 'undefined' || !('mediaSession' in navigator)) return;

    const artwork = track.artworkUrl
      ? [{ src: track.artworkUrl, sizes: '512x512', type: 'image/jpeg' }]
      : [];

    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist || 'Unknown Artist',
      album: track.album || 'SONORA Library',
      artwork,
    });
  }, []);

  // Play a track
  const playTrack = useCallback(
    async (track: Track, newQueue?: Track[]) => {
      setErrorMessage(undefined);

      // Handle queue update if specified
      if (newQueue && newQueue.length > 0) {
        const queueItems: QueueItem[] = newQueue.map((t) => ({
          id: `q_${t.id}_${Math.random().toString(36).slice(2, 7)}`,
          track: t,
          status: t.id === track.id ? 'playing' : 'ready',
        }));
        setQueue(queueItems);
        const idx = queueItems.findIndex((q) => q.track.id === track.id);
        setQueueIndex(idx >= 0 ? idx : 0);
      } else {
        // If not in existing queue, add or set index
        setQueue((prev) => {
          const existingIdx = prev.findIndex((item) => item.track.id === track.id);
          if (existingIdx >= 0) {
            setQueueIndex(existingIdx);
            return prev.map((item, i) => ({
              ...item,
              status: i === existingIdx ? 'playing' : 'ready',
            }));
          } else {
            const newItem: QueueItem = {
              id: `q_${track.id}_${Math.random().toString(36).slice(2, 7)}`,
              track,
              status: 'playing',
            };
            const updated = [...prev, newItem];
            setQueueIndex(updated.length - 1);
            return updated;
          }
        });
      }

      setCurrentTrack(track);
      updateMediaSession(track);
      recordHistory(track.id).catch(() => {});

      // Stop previous audio element
      const audio = audioRef.current;
      if (audio) {
        audio.pause();
        audio.currentTime = 0;
      }

      // Check track source
      if (track.source === 'local') {
        setActiveProvider('local');
        setEmbedUrl(undefined);
        setStatus('loading');

        if (!track.localBlob) {
          setStatus('error');
          setErrorMessage('Audio file data is not available in local storage.');
          return;
        }

        // Cleanup old object URL
        if (currentObjectUrlRef.current) {
          URL.revokeObjectURL(currentObjectUrlRef.current);
          currentObjectUrlRef.current = null;
        }

        try {
          const blobUrl = URL.createObjectURL(track.localBlob);
          currentObjectUrlRef.current = blobUrl;

          if (audio) {
            audio.src = blobUrl;
            audio.volume = isMuted ? 0 : volume;
            await audio.play();
            setStatus('playing');
          }
        } catch (err: any) {
          setStatus('error');
          setErrorMessage(err?.message || 'Playback was blocked or encountered an error.');
        }
      } else if (track.source === 'youtube-embed') {
        setActiveProvider('youtube');
        setEmbedUrl(track.sourceUrl);
        setStatus('playing');
        setCurrentTime(0);
        setDuration(track.duration || 0);
      } else if (track.source === 'spotify-embed') {
        setActiveProvider('spotify');
        setEmbedUrl(track.sourceUrl);
        setStatus('playing');
        setCurrentTime(0);
        setDuration(track.duration || 0);
      } else {
        setActiveProvider('external');
        setEmbedUrl(undefined);
        setStatus('idle');
      }
    },
    [volume, isMuted, updateMediaSession]
  );

  // Play / Pause toggle
  const togglePlayPause = useCallback(() => {
    if (!currentTrack) return;

    if (activeProvider === 'local') {
      const audio = audioRef.current;
      if (!audio) return;
      if (audio.paused) {
        audio.play().then(() => setStatus('playing')).catch(() => setStatus('error'));
      } else {
        audio.pause();
        setStatus('paused');
      }
    } else {
      setStatus((prev) => (prev === 'playing' ? 'paused' : 'playing'));
    }
  }, [currentTrack, activeProvider]);

  const pause = useCallback(() => {
    if (activeProvider === 'local') {
      audioRef.current?.pause();
    }
    setStatus('paused');
  }, [activeProvider]);

  const resume = useCallback(() => {
    if (activeProvider === 'local') {
      audioRef.current?.play().catch(() => {});
    }
    setStatus('playing');
  }, [activeProvider]);

  const seek = useCallback((seconds: number) => {
    if (audioRef.current && isFinite(seconds)) {
      audioRef.current.currentTime = seconds;
      setCurrentTime(seconds);
    }
  }, []);

  const setVolume = useCallback((vol: number) => {
    const clamped = Math.max(0, Math.min(1, vol));
    setVolumeState(clamped);
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : clamped;
    }
  }, [isMuted]);

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      if (audioRef.current) {
        audioRef.current.volume = next ? 0 : volume;
      }
      return next;
    });
  }, [volume]);

  // Next / Previous
  const skipNext = useCallback(() => {
    if (queue.length === 0) return;

    let nextIndex = queueIndex + 1;
    if (isShuffle) {
      nextIndex = Math.floor(Math.random() * queue.length);
    } else if (nextIndex >= queue.length) {
      if (repeatMode === 'all') {
        nextIndex = 0;
      } else {
        return; // reached end
      }
    }

    if (queue[nextIndex]) {
      setQueueIndex(nextIndex);
      playTrack(queue[nextIndex].track);
    }
  }, [queue, queueIndex, isShuffle, repeatMode, playTrack]);

  const skipPrevious = useCallback(() => {
    if (queue.length === 0) return;

    // If more than 3 seconds in, seek to start
    if (currentTime > 3) {
      seek(0);
      return;
    }

    const prevIndex = queueIndex > 0 ? queueIndex - 1 : queue.length - 1;
    if (queue[prevIndex]) {
      setQueueIndex(prevIndex);
      playTrack(queue[prevIndex].track);
    }
  }, [queue, queueIndex, currentTime, seek, playTrack]);

  // Hook audio element ended event
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onEnded = () => {
      if (repeatMode === 'one' && currentTrack) {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      } else {
        skipNext();
      }
    };

    audio.addEventListener('ended', onEnded);
    return () => audio.removeEventListener('ended', onEnded);
  }, [repeatMode, currentTrack, skipNext]);

  // MediaSession action handlers
  useEffect(() => {
    if (typeof window === 'undefined' || !('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.setActionHandler('play', () => resume());
      navigator.mediaSession.setActionHandler('pause', () => pause());
      navigator.mediaSession.setActionHandler('previoustrack', () => skipPrevious());
      navigator.mediaSession.setActionHandler('nexttrack', () => skipNext());
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined) seek(details.seekTime);
      });
    } catch {
      // not all handlers supported everywhere
    }
  }, [resume, pause, skipPrevious, skipNext, seek]);

  const toggleShuffle = useCallback(() => {
    setIsShuffle((prev) => !prev);
  }, []);

  const addToQueue = useCallback((track: Track) => {
    const newItem: QueueItem = {
      id: `q_${track.id}_${Math.random().toString(36).slice(2, 7)}`,
      track,
      status: 'ready',
    };
    setQueue((prev) => [...prev, newItem]);
  }, []);

  const removeFromQueue = useCallback((queueItemId: string) => {
    setQueue((prev) => prev.filter((item) => item.id !== queueItemId));
  }, []);

  const reorderQueue = useCallback((fromIndex: number, toIndex: number) => {
    setQueue((prev) => {
      const copy = [...prev];
      const [moved] = copy.splice(fromIndex, 1);
      copy.splice(toIndex, 0, moved);
      return copy;
    });
  }, []);

  const clearQueue = useCallback(() => {
    setQueue([]);
    setQueueIndex(-1);
  }, []);

  const toggleFavorite = useCallback(async (trackId: string) => {
    try {
      const newStatus = await dbToggleFavorite(trackId);
      setCurrentTrack((prev) => {
        if (prev && prev.id === trackId) {
          return { ...prev, isFavorite: newStatus };
        }
        return prev;
      });
      setQueue((prev) =>
        prev.map((item) =>
          item.track.id === trackId
            ? { ...item, track: { ...item.track, isFavorite: newStatus } }
            : item
        )
      );
    } catch {
      // ignore
    }
  }, []);

  const handleTracksRemoved = useCallback(
    (trackIds: string[]) => {
      if (!trackIds || trackIds.length === 0) return;
      const removedSet = new Set(trackIds);

      // If currently playing track was deleted, stop playback and release resources
      if (currentTrack && removedSet.has(currentTrack.id)) {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.removeAttribute('src');
          audioRef.current.load();
          audioRef.current.currentTime = 0;
        }
        if (currentObjectUrlRef.current) {
          try {
            URL.revokeObjectURL(currentObjectUrlRef.current);
          } catch {
            // ignore
          }
          currentObjectUrlRef.current = null;
        }
        setCurrentTrack(null);
        setStatus('idle');
        setCurrentTime(0);
        setDuration(0);
        setActiveProvider(null);
        setEmbedUrl(undefined);
        setIsFullPlayerOpen(false);

        if (typeof window !== 'undefined' && 'mediaSession' in navigator) {
          try {
            navigator.mediaSession.metadata = null;
          } catch {
            // ignore
          }
        }
      }

      // Purge deleted tracks from the active queue
      setQueue((prevQueue) => {
        const remaining = prevQueue.filter((item) => !removedSet.has(item.track.id));
        return remaining;
      });

      setQueueIndex(-1);
    },
    [currentTrack]
  );

  // Execute Discord-style commands
  const executeCommand = useCallback(
    async (cmdStr: string): Promise<CommandResult> => {
      const parsed = parseCommand(cmdStr);

      if (parsed.error) {
        return { success: false, action: parsed.action, message: parsed.error };
      }

      switch (parsed.action) {
        case 'play': {
          if (!parsed.arg) return { success: false, action: 'play', message: 'No music URL or track name provided.' };
          const isUrl = /^https?:\/\//i.test(parsed.arg);

          if (!isUrl) {
            // Search local library
            const localTracks = await getAllTracks();
            const query = parsed.arg.toLowerCase();
            const matched = localTracks.find(
              (t) =>
                t.title.toLowerCase().includes(query) ||
                (t.artist && t.artist.toLowerCase().includes(query)) ||
                (t.fileName && t.fileName.toLowerCase().includes(query))
            );

            if (matched) {
              await playTrack(matched);
              return {
                success: true,
                action: 'play',
                message: `Now playing local track: "${matched.title}" by ${matched.artist || 'Unknown Artist'}`,
              };
            }
          }

          const resolved = await resolveMediaUrl(parsed.arg);
          if (!resolved.playable) {
            return {
              success: false,
              action: 'play',
              message: resolved.reason || `No local track matched "${parsed.arg}", and direct online playback is unsupported.`,
            };
          }

          const onlineTrack: Track = {
            id: `online_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            title: resolved.title || 'Online Track',
            artist: resolved.artist || 'Online Provider',
            artworkUrl: resolved.artworkUrl,
            source: resolved.provider === 'youtube' ? 'youtube-embed' : 'spotify-embed',
            sourceUrl: resolved.embedUrl || resolved.canonicalUrl,
            addedAt: Date.now(),
            isFavorite: false,
          };

          await playTrack(onlineTrack);
          return {
            success: true,
            action: 'play',
            message: `Now playing: ${onlineTrack.title} (${resolved.provider.toUpperCase()})`,
          };
        }

        case 'add': {
          if (!parsed.arg) return { success: false, action: 'add', message: 'No music URL or track name provided.' };
          const isUrl = /^https?:\/\//i.test(parsed.arg);

          if (!isUrl) {
            // Search local library
            const localTracks = await getAllTracks();
            const query = parsed.arg.toLowerCase();
            const matched = localTracks.find(
              (t) =>
                t.title.toLowerCase().includes(query) ||
                (t.artist && t.artist.toLowerCase().includes(query)) ||
                (t.fileName && t.fileName.toLowerCase().includes(query))
            );

            if (matched) {
              addToQueue(matched);
              return {
                success: true,
                action: 'add',
                message: `Added local track to queue: "${matched.title}"`,
              };
            }
          }

          const resolved = await resolveMediaUrl(parsed.arg);
          if (!resolved.playable) {
            return {
              success: false,
              action: 'add',
              message: resolved.reason || `No local track matched "${parsed.arg}", and direct online playback is unsupported.`,
            };
          }

          const onlineTrack: Track = {
            id: `online_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            title: resolved.title || 'Online Track',
            artist: resolved.artist || 'Online Provider',
            artworkUrl: resolved.artworkUrl,
            source: resolved.provider === 'youtube' ? 'youtube-embed' : 'spotify-embed',
            sourceUrl: resolved.embedUrl || resolved.canonicalUrl,
            addedAt: Date.now(),
            isFavorite: false,
          };

          addToQueue(onlineTrack);
          return {
            success: true,
            action: 'add',
            message: `Added to queue: ${onlineTrack.title}`,
          };
        }

        case 'pause':
          pause();
          return { success: true, action: 'pause', message: 'Playback paused.' };

        case 'resume':
          resume();
          return { success: true, action: 'resume', message: 'Playback resumed.' };

        case 'skip':
          skipNext();
          return { success: true, action: 'skip', message: 'Skipped to next track.' };

        case 'back':
          skipPrevious();
          return { success: true, action: 'back', message: 'Returned to previous track.' };

        case 'clear':
          clearQueue();
          return { success: true, action: 'clear', message: 'Queue cleared.' };

        case 'shuffle':
          toggleShuffle();
          return {
            success: true,
            action: 'shuffle',
            message: `Shuffle is now ${!isShuffle ? 'ON' : 'OFF'}.`,
          };

        case 'repeat':
          if (parsed.repeatMode) {
            setRepeatMode(parsed.repeatMode);
            return {
              success: true,
              action: 'repeat',
              message: `Repeat mode set to: ${parsed.repeatMode.toUpperCase()}`,
            };
          }
          return { success: false, action: 'repeat', message: 'Invalid repeat mode.' };

        case 'help':
          return {
            success: true,
            action: 'help',
            message: 'Available commands:\n' + COMMAND_HELP_LIST.map((c) => `${c.command} — ${c.desc}`).join('\n'),
          };

        default:
          return { success: false, action: 'unknown', message: 'Unknown command. Type /help for list.' };
      }
    },
    [playTrack, addToQueue, pause, resume, skipNext, skipPrevious, clearQueue, toggleShuffle, isShuffle]
  );

  return (
    <AudioPlayerContext.Provider
      value={{
        currentTrack,
        status,
        currentTime,
        duration,
        volume,
        isMuted,
        repeatMode,
        isShuffle,
        queue,
        queueIndex,
        errorMessage,
        activeProvider,
        embedUrl,
        isFullPlayerOpen,
        isOnline,
        playTrack,
        togglePlayPause,
        pause,
        resume,
        seek,
        setVolume,
        toggleMute,
        skipNext,
        skipPrevious,
        toggleShuffle,
        setRepeatMode,
        addToQueue,
        removeFromQueue,
        reorderQueue,
        clearQueue,
        executeCommand,
        openFullPlayer: () => setIsFullPlayerOpen(true),
        closeFullPlayer: () => setIsFullPlayerOpen(false),
        toggleFavorite,
        handleTracksRemoved,
      }}
    >
      {children}
    </AudioPlayerContext.Provider>
  );
}

export function useAudioPlayer() {
  const ctx = useContext(AudioPlayerContext);
  if (!ctx) {
    throw new Error('useAudioPlayer must be used within an AudioPlayerProvider');
  }
  return ctx;
}
