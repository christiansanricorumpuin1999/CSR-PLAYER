import test from 'node:test';
import assert from 'node:assert/strict';
import { parseCommand } from './commandParser';

test('parseCommand handles direct URLs without slash', () => {
  const result = parseCommand('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  assert.equal(result.action, 'play');
  assert.equal(result.arg, 'https://www.youtube.com/watch?v=dQw4w9WgXcQ');
});

test('parseCommand handles /play with URL argument', () => {
  const result = parseCommand('/play https://open.spotify.com/track/123');
  assert.equal(result.action, 'play');
  assert.equal(result.arg, 'https://open.spotify.com/track/123');
});

test('parseCommand handles /play without argument with error', () => {
  const result = parseCommand('/play');
  assert.equal(result.action, 'play');
  assert.ok(result.error);
});

test('parseCommand handles /add with URL argument', () => {
  const result = parseCommand('/add https://youtu.be/xyz');
  assert.equal(result.action, 'add');
  assert.equal(result.arg, 'https://youtu.be/xyz');
});

test('parseCommand handles playback controls', () => {
  assert.equal(parseCommand('/pause').action, 'pause');
  assert.equal(parseCommand('/resume').action, 'resume');
  assert.equal(parseCommand('/skip').action, 'skip');
  assert.equal(parseCommand('/back').action, 'back');
  assert.equal(parseCommand('/clear').action, 'clear');
  assert.equal(parseCommand('/shuffle').action, 'shuffle');
  assert.equal(parseCommand('/help').action, 'help');
});

test('parseCommand handles /repeat modes', () => {
  assert.equal(parseCommand('/repeat one').repeatMode, 'one');
  assert.equal(parseCommand('/repeat all').repeatMode, 'all');
  assert.equal(parseCommand('/repeat off').repeatMode, 'off');
  assert.ok(parseCommand('/repeat invalid').error);
});
