import { CommandResult, RepeatMode } from './types';

export interface ParsedCommand {
  action:
    | 'play'
    | 'add'
    | 'pause'
    | 'resume'
    | 'skip'
    | 'back'
    | 'clear'
    | 'shuffle'
    | 'repeat'
    | 'help'
    | 'unknown';
  arg?: string;
  repeatMode?: RepeatMode;
  error?: string;
}

export function parseCommand(input: string): ParsedCommand {
  const trimmed = input.trim();
  if (!trimmed) {
    return { action: 'unknown', error: 'Command cannot be empty' };
  }

  // If starts with URL directly (http:// or https://)
  if (/^https?:\/\//i.test(trimmed)) {
    return { action: 'play', arg: trimmed };
  }

  // If command starts with '/'
  if (trimmed.startsWith('/')) {
    const parts = trimmed.slice(1).trim().split(/\s+/);
    const commandName = parts[0]?.toLowerCase();
    const arg = parts.slice(1).join(' ').trim();

    switch (commandName) {
      case 'play':
      case 'p':
        if (!arg) {
          return {
            action: 'play',
            error: 'Usage: /play <music URL or keywords>',
          };
        }
        return { action: 'play', arg };

      case 'add':
      case 'queue':
        if (!arg) {
          return {
            action: 'add',
            error: 'Usage: /add <music URL>',
          };
        }
        return { action: 'add', arg };

      case 'pause':
        return { action: 'pause' };

      case 'resume':
      case 'unpause':
        return { action: 'resume' };

      case 'skip':
      case 'next':
        return { action: 'skip' };

      case 'back':
      case 'prev':
      case 'previous':
        return { action: 'back' };

      case 'clear':
        return { action: 'clear' };

      case 'shuffle':
        return { action: 'shuffle' };

      case 'repeat':
      case 'loop': {
        const mode = arg.toLowerCase();
        if (mode === 'off' || mode === 'one' || mode === 'all') {
          return { action: 'repeat', repeatMode: mode as RepeatMode };
        }
        return {
          action: 'repeat',
          error: 'Usage: /repeat <off|one|all>',
        };
      }

      case 'help':
      case 'commands':
        return { action: 'help' };

      default:
        return {
          action: 'unknown',
          error: `Unknown command: /${commandName}. Type /help for available commands.`,
        };
    }
  }

  // If text without slash looks like a URL
  try {
    const url = new URL(trimmed);
    if (url.protocol === 'http:' || url.protocol === 'https:') {
      return { action: 'play', arg: trimmed };
    }
  } catch {
    // not a valid URL
  }

  return {
    action: 'unknown',
    error: `Unrecognized input. Try /play <url>, /help, or a direct link.`,
  };
}

export const COMMAND_HELP_LIST = [
  { command: '/play <url>', desc: 'Resolve music link and play immediately' },
  { command: '/add <url>', desc: 'Resolve music link and append to queue' },
  { command: '/pause', desc: 'Pause current playback' },
  { command: '/resume', desc: 'Resume paused playback' },
  { command: '/skip', desc: 'Skip to next track in queue' },
  { command: '/back', desc: 'Go back to previous track' },
  { command: '/shuffle', desc: 'Toggle shuffle order' },
  { command: '/repeat <off|one|all>', desc: 'Set repeat mode' },
  { command: '/clear', desc: 'Clear all items in queue' },
  { command: '/help', desc: 'Show this commands guide' },
];
