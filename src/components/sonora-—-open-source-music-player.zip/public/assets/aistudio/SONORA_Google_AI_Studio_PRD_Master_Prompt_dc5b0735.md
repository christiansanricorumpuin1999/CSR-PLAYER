# SONORA — Open-Source Music Player
## Product Requirements, Technical Specification, User Flow, and Build Prompt

> **Tujuan dokumen:** Jadikan file ini sebagai spesifikasi utama ketika membangun SONORA di Google AI Studio Build Mode. Gunakan gambar referensi yang diunggah sebagai referensi visual, bukan sebagai template yang harus disalin.

---

# 1. PROJECT OVERVIEW

**Nama produk:** SONORA  
**Jenis:** Open-source music player berbasis web, responsif, dan installable sebagai PWA  
**Platform awal:** Web desktop dan mobile, dengan prioritas pengalaman Android/mobile browser  
**Model akses:** Public app, tanpa akun, tanpa registrasi, tanpa username/password  
**Prinsip utama:** Real functionality only — tidak boleh ada data, tombol, API, hasil pencarian, playlist, atau integrasi palsu/dummy.

SONORA adalah pemutar musik pribadi yang menggabungkan:
1. Pemutaran file musik lokal secara offline.
2. Pengelolaan library musik lokal.
3. Pemutar online melalui sumber yang memang menyediakan integrasi resmi.
4. Input tautan musik dengan sistem resolver/adapters.
5. Antrean musik dengan pengalaman seperti perintah `/play` pada bot Discord.
6. PWA yang dapat dipasang dan membuka library lokal ketika offline.

**Penting:** Jangan menjanjikan bahwa setiap URL dari YouTube, Spotify, MetroList, atau layanan lain dapat diubah menjadi audio langsung. Setiap layanan memiliki API, autentikasi, batasan embed, dan ketentuan penggunaan yang berbeda. Jangan mengunduh, mengekstrak, mem-proxy, atau mengakali proteksi audio. Jika sumber tidak menyediakan cara playback yang sah, tampilkan metadata/link dan opsi membuka aplikasi/situs aslinya, bukan audio palsu.

---

# 2. VISUAL DIRECTION & DESIGN SYSTEM

Gunakan gambar referensi yang dilampirkan sebagai acuan untuk **karakter visual**, bukan menyalin susunan kartu secara identik. Buat layout, navigasi, komposisi, dan identitas SONORA sendiri.

## 2.1 Art direction
- Editorial music-player UI yang playful, modern, hangat, dan sedikit retro.
- Ilustrasi cover bergaya anime-inspired / hand-painted editorial, bukan foto stok generik.
- Kartu dengan sudut membulat, outline tipis, bayangan sangat lembut, dan ruang kosong yang lega.
- Bentuk dekoratif sederhana: lingkaran, blob, stiker label seperti `PLAYING`, `NEW`, `OFFLINE`, `FAV`.
- Hindari tampilan dashboard SaaS yang kaku dan hindari meniru Spotify secara langsung.
- Artwork yang tidak tersedia harus memakai placeholder visual netral yang dibuat dari inisial/warna metadata; jangan mengarang cover seolah-olah artwork asli.

## 2.2 Color palette
Gunakan token warna berikut secara konsisten:

| Token | Hex | Penggunaan |
|---|---|---|
| `canvas` | `#F5F2E8` | Background utama warm cream |
| `surface` | `#FFFEFA` | Kartu dan panel |
| `ink` | `#20252D` | Teks utama dan ikon |
| `muted` | `#777777` | Teks sekunder |
| `cobalt` | `#354BCB` | Aksi utama, selected state, player |
| `coral` | `#F47768` | Highlight dan aksen |
| `lemon` | `#F5E94A` | Banner/notifikasi |
| `lavender` | `#B9A6F2` | Chip, artwork accents |
| `mint` | `#A8E6D8` | Status offline/success |
| `line` | `#343434` | Outline tipis |

Warna harus tetap memiliki kontras teks yang memadai. Jangan gunakan semua aksen sekaligus pada satu komponen.

## 2.3 Typography
- Gunakan **Nunito Sans** atau **Plus Jakarta Sans** untuk teks UI.
- Heading tebal, rounded, geometric, uppercase hanya untuk label pendek.
- Ukuran heading jelas, body nyaman dibaca, metadata lebih kecil.
- Jangan gunakan font serif atau condensed display font.

## 2.4 Layout
Buat komposisi yang berbeda dari referensi:
- Desktop: sidebar kiri, konten utama di tengah, mini-player/sticky player di bawah.
- Mobile: bottom navigation, mini-player sticky di atas navigation, full-screen player saat artwork/player disentuh.
- Halaman utama berisi greeting, recently played, playlist/library shortcuts, dan queue preview.
- Gunakan grid responsif dan jangan memaksa desktop layout pada layar mobile.

## 2.5 Motion
- Transisi 150–250ms untuk hover, tab, drawer, dan player.
- Animasi equalizer hanya saat audio benar-benar sedang diputar.
- Hormati `prefers-reduced-motion`.
- Jangan membuat animasi berat yang mengganggu playback.

---

# 3. NO-LOGIN WELCOME EXPERIENCE

Aplikasi ini **tidak memiliki sistem akun**.

Saat pertama kali dibuka:
1. Tampilkan welcome screen dengan logo SONORA, tagline, dan ilustrasi sederhana.
2. Teks: “Your music. Your space. Welcome to SONORA.”
3. Tombol `Enter SONORA` untuk masuk ke aplikasi.
4. Tombol `Explore offline mode` boleh langsung menuju library.
5. Tidak ada field email, username, password, OTP, register, atau sign-in.
6. Setelah welcome selesai, simpan status onboarding secara lokal agar tidak muncul setiap kali aplikasi dibuka.
7. Sediakan `Replay welcome` di Settings.
8. Jangan menyebut tombol ini sebagai login. Ini hanya welcome/onboarding.

Aplikasi harus tetap dapat digunakan tanpa akun, tanpa backend account, dan tanpa mengirim library pribadi ke server.

---

# 4. INFORMATION ARCHITECTURE

Navigasi utama:
1. **Home** — ringkasan aktivitas dan akses cepat.
2. **Library** — seluruh file lokal, album, artist, folder, dan playlist.
3. **Online** — input URL, layanan yang didukung, dan hasil resolusi.
4. **Queue** — antrean pemutaran dan kontrol urutan.
5. **Favorites** — lagu favorit.
6. **Settings** — tema, audio, storage, sumber online, data, dan informasi open-source.

Halaman/detail:
- Welcome
- Home
- Library / All Tracks
- Albums
- Artists
- Folders
- Playlists
- Import Music
- Online Link Resolver
- Full Player
- Queue
- Favorites
- Settings
- About / Open Source
- Error and unsupported-source states

---

# 5. CORE FEATURES

## 5.1 Offline music library

Wajib bekerja dengan file audio yang benar-benar dipilih pengguna.

**Import:**
- Gunakan file picker multi-select.
- Pada browser yang mendukungnya, sediakan folder picker.
- Drag-and-drop untuk desktop.
- Terima format yang didukung browser, minimal MP3, WAV, OGG, M4A/AAC, dan FLAC jika browser mendukung decoding-nya.
- Validasi MIME type dan ekstensi; jangan menganggap semua file pasti dapat diputar.
- Tampilkan progres import dan error per file.
- Cegah duplikasi menggunakan kombinasi metadata, ukuran file, dan fingerprint yang realistis; jangan mengandalkan nama file saja.

**Metadata:**
- Baca title, artist, album, duration, track number, genre, year, dan embedded artwork jika tersedia.
- Gunakan library metadata yang kompatibel dengan browser.
- Jika metadata kosong, tampilkan nama file sebagai fallback dan beri label metadata belum tersedia.
- Jangan membuat nama artis, album, atau durasi palsu.

**Storage:**
- Simpan metadata dan blob file menggunakan IndexedDB.
- Gunakan object URL hanya saat dibutuhkan dan revoke ketika tidak lagi dipakai.
- Tampilkan estimasi storage dan tangani `QuotaExceededError`.
- Sediakan penghapusan satu lagu, beberapa lagu, atau seluruh library lokal dengan konfirmasi.
- Data library bersifat lokal pada browser/perangkat tersebut. Jangan mengklaim otomatis tersinkron ke perangkat lain.
- Jangan upload file pribadi ke backend.

**Playback:**
- Gunakan HTMLAudioElement/Web Audio API sesuai kebutuhan.
- Support play, pause, seek, volume, mute, previous, next, repeat, shuffle.
- Tampilkan durasi dan progress dari event audio nyata.
- Tangani file rusak, format tidak didukung, file hilang, dan decode error.
- Playback harus tetap berjalan ketika berpindah halaman di dalam aplikasi.
- Gunakan Media Session API jika didukung browser untuk lock-screen/media controls.
- Offline playback harus tetap berfungsi setelah aplikasi dibuka kembali selama data lokal masih tersedia.

## 5.2 Library management
- Search berdasarkan judul, artis, album, dan nama file.
- Sort: title, artist, album, recently added, duration.
- Filter berdasarkan format, folder, dan status favorit.
- Buat, rename, edit, dan hapus playlist lokal.
- Add/remove lagu ke playlist.
- Multi-select dan bulk actions.
- Recently played hanya diisi dari playback nyata.
- Favorites disimpan lokal.
- Empty state harus memberi tombol `Import music`, bukan daftar contoh.

## 5.3 Online link resolver

Buat satu kolom `Paste a music link` dan tombol `Resolve link`.

Resolver harus:
1. Memvalidasi URL.
2. Mengenali domain/provider yang didukung.
3. Mengambil metadata hanya melalui API resmi atau endpoint publik yang diizinkan.
4. Mengembalikan tipe sumber dan metode playback yang tersedia.
5. Menampilkan status `Playable`, `Open in provider`, `Metadata only`, atau `Unsupported`.
6. Tidak pernah mengklaim berhasil sebelum sumber benar-benar tervalidasi.
7. Menampilkan alasan dan tindakan berikutnya jika gagal.
8. Memasukkan item ke queue hanya jika playback method tersedia dan berhasil diinisialisasi.

### Provider policy

**YouTube**
- Gunakan YouTube IFrame Player API / embedded player resmi untuk video yang dapat di-embed.
- Kendalikan playback melalui API yang didokumentasikan.
- Hormati video yang menonaktifkan embedding, batasan wilayah, age restrictions, dan error provider.
- Jangan download, rip, extract audio, menghapus iklan, menyembunyikan attribution/branding wajib, atau memakai endpoint tidak resmi untuk mengambil stream.
- Jika video tidak dapat di-embed, tampilkan `Open on YouTube`.
- Jangan menjanjikan background audio-only playback dari YouTube.

**Spotify**
- Gunakan Spotify oEmbed/metadata dan Spotify Embed untuk preview/playback yang memang disediakan.
- Spotify Web Playback SDK hanya sebagai integrasi opsional jika konfigurasi OAuth, izin, akun Premium, dan syarat Spotify terpenuhi.
- Jangan menganggap Spotify URL sebagai direct audio URL.
- Jangan mengekstrak audio dari Spotify atau mem-proxy stream.
- Jika autentikasi/izin tidak tersedia, tetap tampilkan opsi `Open in Spotify` atau embed resmi yang tersedia.
- Jangan meminta kredensial Spotify di form buatan sendiri; gunakan OAuth resmi bila fitur SDK diaktifkan.

**MetroList / Metrolist**
- Perlakukan sebagai aplikasi pihak ketiga, bukan layanan yang otomatis memiliki API publik.
- Jangan mengasumsikan ada API stabil atau endpoint resmi.
- Implementasikan adapter hanya jika tersedia dokumentasi/API/deep link resmi yang dapat diverifikasi.
- Jika tidak ada integrasi resmi yang dapat diverifikasi, tampilkan `Unsupported direct playback` dan opsi membuka link/aplikasi eksternal bila deep link yang valid diketahui.
- Jangan scraping, reverse-engineer endpoint privat, atau mengandalkan API tidak resmi.

**Other providers**
- Arsitektur adapter harus memungkinkan penambahan provider baru.
- Tambahkan provider hanya setelah dokumentasi, izin, dan metode playback diverifikasi.
- Provider tanpa metode sah tetap dapat ditampilkan sebagai external link, bukan playable track.

## 5.4 Discord-style command input

Buat command bar dengan placeholder:
`Try /play <music URL>`

Perintah yang didukung:
- `/play <url>` — validasi link, resolve, lalu play atau tambahkan ke queue sesuai setting.
- `/add <url>` — resolve dan tambahkan ke queue.
- `/pause` — pause audio aktif.
- `/resume` — lanjutkan playback.
- `/skip` — next track.
- `/back` — previous track.
- `/clear` — kosongkan queue setelah konfirmasi.
- `/shuffle` — toggle shuffle.
- `/repeat off|one|all` — ubah repeat mode.
- `/help` — tampilkan daftar command.

Perilaku:
- Input command harus menjalankan aksi nyata dan menggunakan player state yang sama dengan UI.
- Validasi argument dan tampilkan pesan error yang jelas.
- Jangan menampilkan command sukses jika aksinya gagal.
- Jika user memasukkan URL biasa tanpa command, perlakukan sebagai `/play <url>`.
- Ini adalah command interface lokal seperti bot Discord; jangan mengklaim terhubung ke Discord server.
- Integrasi Discord bot sungguhan merupakan fitur terpisah yang membutuhkan bot application, token rahasia, server backend, dan konfigurasi Discord. Jangan membuat token palsu atau menyimpan token di frontend.

## 5.5 Music player

Player harus menjadi pusat pengalaman aplikasi:
- Artwork besar dan metadata lagu yang sedang diputar.
- Play/pause, previous, next.
- Seek bar dengan current time dan total duration.
- Volume dan mute.
- Shuffle, repeat one/all/off.
- Favorite.
- Queue shortcut.
- Mini-player sticky.
- Full player view.
- Equalizer visual yang mengikuti audio nyata jika memungkinkan; jika tidak, gunakan indikator playback sederhana.
- Source badge: `LOCAL`, `YOUTUBE EMBED`, `SPOTIFY EMBED`, dan seterusnya.
- Untuk provider embed, tampilkan player provider sesuai aturan branding dan ukuran minimum yang diwajibkan.

**Satu playback engine aktif pada satu waktu.** Ketika berpindah dari local audio ke provider embed, hentikan playback sebelumnya agar tidak ada dua audio yang berjalan bersamaan.

---

# 6. TECHNICAL ARCHITECTURE

## 6.1 Recommended stack
- React + TypeScript.
- Vite atau struktur React yang dihasilkan Google AI Studio; ikuti runtime AI Studio yang tersedia.
- Tailwind CSS untuk styling dan design tokens.
- Lucide icons.
- IndexedDB menggunakan Dexie atau library sejenis.
- HTMLAudioElement untuk file lokal.
- Service Worker + Web App Manifest untuk PWA.
- Metadata parser yang berjalan di browser.
- Vitest + React Testing Library untuk unit/component tests.
- Playwright bila tersedia untuk end-to-end tests.

Jangan menambahkan backend, database cloud, atau authentication hanya karena template generator menyediakannya. Aplikasi harus local-first. Backend hanya ditambahkan jika integrasi provider benar-benar membutuhkannya.

## 6.2 Suggested project structure

```text
src/
  app/
    App.tsx
    routes.tsx
    providers/
  components/
    layout/
    navigation/
    music/
    library/
    online/
    queue/
    feedback/
  pages/
    WelcomePage.tsx
    HomePage.tsx
    LibraryPage.tsx
    OnlinePage.tsx
    QueuePage.tsx
    FavoritesPage.tsx
    SettingsPage.tsx
  audio/
    AudioEngine.ts
    MediaSession.ts
    playbackStore.ts
  library/
    db.ts
    importAudio.ts
    metadataParser.ts
    libraryRepository.ts
  providers/
    ProviderAdapter.ts
    resolver.ts
    youtube/
    spotify/
    external/
  commands/
    commandParser.ts
    commandExecutor.ts
  hooks/
  styles/
    tokens.css
    globals.css
  tests/
public/
  manifest.webmanifest
  service-worker.js
```

Struktur boleh disesuaikan, tetapi pisahkan UI, data layer, playback engine, dan provider adapters.

## 6.3 Data model

Contoh struktur konseptual (sesuaikan implementasi IndexedDB):

```ts
type TrackSource =
  | "local"
  | "youtube-embed"
  | "spotify-embed"
  | "external";

interface Track {
  id: string;
  title: string;
  artist?: string;
  album?: string;
  duration?: number;
  artworkBlob?: Blob;
  source: TrackSource;
  sourceUrl?: string;
  localBlob?: Blob;
  mimeType?: string;
  addedAt: number;
  lastPlayedAt?: number;
  isFavorite: boolean;
}

interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
  updatedAt: number;
}

interface QueueItem {
  id: string;
  trackId?: string;
  sourceUrl?: string;
  status: "resolving" | "ready" | "playing" | "failed";
  error?: string;
}
```

Jangan menyimpan access token provider di IndexedDB atau localStorage. Rahasia dan token harus mengikuti pola OAuth/provider yang aman.

## 6.4 Provider adapter contract

Buat interface yang eksplisit, misalnya:

```ts
interface ProviderAdapter {
  id: string;
  canHandle(url: URL): boolean;
  resolve(url: URL): Promise<ResolvedMedia>;
  createPlayer(container: HTMLElement): Promise<ProviderPlayer>;
}

interface ResolvedMedia {
  provider: string;
  title?: string;
  artist?: string;
  artworkUrl?: string;
  canonicalUrl: string;
  playbackType: "embed" | "sdk" | "external-only";
  playable: boolean;
  reason?: string;
}

interface ProviderPlayer {
  play(): Promise<void>;
  pause(): Promise<void>;
  destroy(): void;
}
```

Tidak semua provider wajib mengimplementasikan semua metode. Jika hanya metadata/link yang diizinkan, adapter harus mengembalikan `playable: false` dan `playbackType: "external-only"`.

## 6.5 PWA and offline behavior
- Cache app shell, CSS, JS, icons, and static assets dengan Service Worker.
- Simpan audio library di IndexedDB, bukan cache HTTP biasa.
- Saat offline, sembunyikan/disable fitur online dengan pesan `You're offline`.
- Library lokal, playlist, favorites, dan playback lokal tetap tersedia.
- Tampilkan indikator online/offline.
- Jangan menjanjikan offline playback untuk stream dari YouTube/Spotify/provider lain.
- Tangani browser storage eviction dan tampilkan peringatan bahwa browser dapat menghapus data situs.
- Berikan fitur export/import metadata library bila memungkinkan; jangan mengklaim file audio ikut ter-export kecuali benar-benar dibuat.

---

# 7. UX STATES & ERROR HANDLING

Setiap fitur wajib memiliki state nyata:
- Loading
- Success
- Empty
- Offline
- Unsupported
- Permission denied
- Storage full
- Invalid URL
- Provider unavailable
- Playback blocked
- File decode error
- Import failed
- No metadata
- No artwork

Contoh pesan:
- `No music in your library yet. Import your first track.`
- `This link is recognized, but direct playback is not supported. Open it in the original app.`
- `This video cannot be embedded by its owner.`
- `Spotify playback requires an eligible Spotify account and authorization.`
- `Your browser storage is almost full. Remove files or export your library data.`
- `This audio format is not supported by your browser.`

Jangan menggunakan fake loading, fake progress, fake search results, fake artists, fake playlists, fake history, atau fake success toast.

---

# 8. SECURITY, PRIVACY & OPEN-SOURCE REQUIREMENTS

- No account system and no user registration.
- No password form.
- No hidden analytics or tracking.
- No upload of local audio files.
- Validate and sanitize user-provided URLs.
- Allow only `https:` URLs for online providers unless a documented deep-link flow requires otherwise.
- Prevent arbitrary URL fetching from the browser/server; use provider allowlists to reduce SSRF risk.
- Do not expose API secrets in frontend bundles.
- Do not commit `.env` or tokens.
- Use official OAuth flows where required.
- Provide a clear privacy notice explaining local browser storage and external provider connections.
- Include `LICENSE` (MIT is a reasonable default, subject to the project owner's choice), `README.md`, setup instructions, and contribution guide.
- Keep provider trademarks and logos within their brand guidelines.
- Do not imply endorsement by YouTube, Spotify, MetroList, or Discord.

---

# 9. FLOWCHART

```mermaid
flowchart TD
    A([Open SONORA]) --> B{Welcome completed?}
    B -- No --> C[Welcome screen]
    C --> D[Enter SONORA]
    B -- Yes --> E[Home]
    D --> E

    E --> F{User action}
    F --> G[Open Library]
    F --> H[Open Online]
    F --> I[Open Queue]
    F --> J[Open Settings]

    G --> K[Import local audio]
    K --> L[Validate files]
    L --> M[Read metadata]
    M --> N[Save blobs and metadata to IndexedDB]
    N --> O[Library updated]
    O --> P[Play local track]

    H --> Q[Paste URL or enter /play URL]
    Q --> R[Validate URL]
    R --> S{Known provider?}
    S -- No --> T[Unsupported link message]
    S -- Yes --> U[Provider adapter resolve]
    U --> V{Allowed playback method?}
    V -- No --> W[Metadata/link only + open provider]
    V -- Yes --> X[Initialize official embed or SDK]
    X --> Y{Playback initialized?}
    Y -- No --> Z[Show provider error]
    Y -- Yes --> AA[Play or add to queue]

    P --> AB[Shared playback state]
    AA --> AB
    AB --> AC[Player controls and Media Session]
    AC --> I
    I --> AD[Reorder / remove / clear queue]
    AD --> AC

    J --> AE[Storage / privacy / theme / welcome]
```

---

# 10. IMPLEMENTATION PHASES

Build in this order. Do not create decorative controls for features that are not implemented.

## Phase 1 — Working foundation
- Set up React + TypeScript project.
- Implement design system and responsive navigation.
- Implement welcome screen without authentication.
- Implement IndexedDB schema and repository.
- Implement local audio import, metadata reading, library list, and local playback.
- Implement mini-player and full player.
- Verify reload persistence and offline local playback.

## Phase 2 — Library experience
- Playlists, favorites, search, filters, sorting, recently played.
- Queue management.
- Media Session API.
- Storage management and error states.

## Phase 3 — Online integrations
- Provider adapter architecture.
- YouTube official IFrame embed integration.
- Spotify embed/metadata integration.
- Optional Spotify Web Playback SDK only after OAuth, account eligibility, and developer setup are available.
- MetroList external-link/deep-link handling only if verified.
- Clear unsupported states for every provider without a legitimate playback route.

## Phase 4 — Command interface and PWA
- Implement `/play`, `/add`, `/pause`, `/resume`, `/skip`, `/back`, `/clear`, `/shuffle`, `/repeat`, `/help`.
- PWA manifest and service worker.
- Offline/online state.
- Installability and mobile layout checks.

## Phase 5 — Quality and release
- Unit, integration, and end-to-end tests.
- Accessibility and keyboard navigation.
- Security review.
- Remove all demo fixtures and mock services.
- README, license, privacy notice, and deployment documentation.

---

# 11. ACCEPTANCE CRITERIA

A feature is complete only when it passes its real-world test.

| Area | Acceptance test |
|---|---|
| Welcome | Opens without login, password, or account creation |
| Import | User can select real audio files |
| Metadata | Reads actual metadata or clearly reports missing metadata |
| Persistence | Imported tracks remain after reload |
| Offline | Previously imported local audio plays with network disabled |
| Player | Play, pause, seek, volume, next, previous work on real audio |
| Queue | Queue order and actions affect actual playback |
| Playlist | Create/edit/delete and add/remove real library tracks |
| Favorites | State persists after reload |
| Search | Returns only actual imported/resolved items |
| YouTube | Official embed plays only when embedding is permitted |
| Spotify | Official embed/SDK behavior follows provider eligibility and auth |
| MetroList | No unsupported API assumptions; external fallback works |
| Commands | Each supported command triggers the same real app actions as UI |
| Errors | Invalid/unsupported sources show truthful errors |
| PWA | App shell loads offline; local library remains usable |
| Privacy | Local files are not uploaded |
| No dummy | No fake tracks, fake search results, fake metrics, or fake success states |

---

# 12. MASTER PROMPT FOR GOOGLE AI STUDIO

**Instruction:** Build the actual application from this specification. Do not merely produce a plan, mockup, or static prototype.

You are a senior product designer and full-stack engineer. Build **SONORA**, a polished, open-source, local-first music player as a responsive React + TypeScript web application/PWA.

Use the uploaded reference image only for its visual language: warm cream canvas, cobalt blue, coral, lemon yellow, lavender and mint accents; rounded geometric sans-serif typography; thin outlines; soft shadows; playful music artwork; editorial card design. Create a clearly original layout and brand identity. Do not copy the reference screen arrangement.

## Mandatory requirements
1. No login, signup, username, password, account, or authentication wall. Show a one-time welcome/onboarding screen with an `Enter SONORA` button only.
2. Implement real local audio import, metadata parsing, IndexedDB persistence, library browsing, playlists, favorites, queue, and audio playback.
3. Local audio must play offline after it has been imported and stored successfully.
4. Build a shared playback engine so all UI controls and command inputs control the same real playback state.
5. Implement an online URL resolver with provider adapters. Use official, documented APIs, SDKs, and embeds only.
6. YouTube must use the official IFrame Player API/embed. Never rip, download, extract, proxy, or bypass restrictions.
7. Spotify must use official embed/metadata or its Web Playback SDK only when OAuth, account eligibility, and provider requirements are met. Never extract Spotify audio.
8. Treat MetroList/Metrolist as unsupported for direct playback unless a verifiable official integration/deep link exists. Do not invent an API.
9. Implement Discord-style local commands: `/play`, `/add`, `/pause`, `/resume`, `/skip`, `/back`, `/clear`, `/shuffle`, `/repeat`, `/help`.
10. Build a real PWA with offline app shell and local-library support. Do not promise offline online-stream playback.
11. Include loading, empty, unsupported, offline, permission, storage, and playback error states.
12. Never create dummy tracks, mock search results, fake artists, fake playlists, fake history, fake API responses, simulated playback, or buttons that do nothing.
13. If an external integration needs credentials, OAuth setup, API approval, or configuration, implement the proper integration boundary and clearly document the exact setup required. Do not fabricate credentials or report it as connected.
14. Do not expose API keys or secrets in client-side code.
15. Do not upload local music files to any server.

## Engineering rules
- First inspect the generated project and the available runtime. Preserve working project configuration.
- Implement in small, coherent modules: UI, IndexedDB repository, import/metadata service, playback engine, queue, command parser, provider adapters, and PWA.
- Use TypeScript types and explicit error handling.
- Use real browser APIs and real provider integrations.
- Every visible button must have a working action or be visibly disabled with an explanation.
- Do not use hardcoded demo content to make the interface look populated. Empty states should guide users to import or connect a real source.
- Do not silently swallow errors.
- Add tests for import, persistence, queue, commands, playback state, URL validation, and provider error states.
- Keep the UI accessible, responsive, keyboard-friendly, and optimized for mobile.
- Do not stop after rendering the home page. Complete the functional flows and run the available build/tests.
- If a feature cannot be implemented legitimately because a provider does not expose a supported API or the required credentials are unavailable, implement an honest unsupported/configuration state rather than a fake feature.

## First build target
Prioritize a fully working offline music player first: welcome → import audio → library → play → queue → playlist/favorites → reload → offline playback. Then add online providers and command input using the same playback state.

At completion, report:
- Features implemented and tested.
- Provider integrations that are genuinely operational.
- Required external setup/credentials, if any.
- Known limitations.
- Build/test results.
- Files changed.

**Definition of done:** SONORA must be a genuinely usable offline-first music player, not a static design prototype.

---

# 13. FOLLOW-UP PROMPTS FOR ITERATION

Use these only after the initial build has completed.

### A. Functional audit
Audit every visible button, menu, form, keyboard action, navigation item, player control, import action, queue action, and command. Trace each interaction to its real implementation. Fix broken handlers, stale state, race conditions, and console errors. Do not add mock behavior. Return a concise pass/fail report with the files changed.

### B. Remove all dummy content
Search the entire project for mock data, placeholder tracks, fake artists, demo playlists, simulated playback, hardcoded search results, fake provider responses, random metrics, and temporary API implementations. Remove them. Connect each feature to its real local database, browser API, or official provider integration. Where no legitimate integration exists, show a clear unsupported/configuration state. Do not leave buttons that pretend to work.

### C. Offline audit
Disable the network and test app-shell loading, IndexedDB library retrieval, local audio playback, playlists, favorites, queue, and navigation. Fix every failure. Verify that online provider actions are clearly disabled or marked unavailable offline.

### D. Provider audit
Test every configured provider against its official documentation and real credentials. Verify URL parsing, metadata, embed initialization, playback events, errors, OAuth requirements, and provider restrictions. Do not claim a provider is supported unless its actual flow works.

### E. Release readiness
Run type checking, linting, tests, and production build. Check mobile and desktop layouts, accessibility, storage quota handling, privacy, secret exposure, and browser console errors. Fix all critical issues before declaring the app complete.

---

# 14. OFFICIAL DOCUMENTATION REFERENCES

Use these as the source of truth during implementation; re-check current provider terms before release.

- Google AI Studio Build mode: https://ai.google.dev/gemini-api/docs/aistudio-build-mode
- YouTube IFrame Player API: https://developers.google.com/youtube/iframe_api_reference
- YouTube embedded player parameters: https://developers.google.com/youtube/player_parameters
- Spotify Web Playback SDK: https://developer.spotify.com/documentation/web-playback-sdk
- Spotify Web Playback SDK setup and requirements: https://developer.spotify.com/documentation/web-playback-sdk/howtos/web-app-player
- Spotify developer policy: https://developer.spotify.com/policy

**Final reminder:** Open-source does not mean bypassing third-party licensing or access restrictions. SONORA should remain useful even when online providers are unavailable because its local/offline music library is a first-class feature.
