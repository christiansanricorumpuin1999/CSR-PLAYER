import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SONORA — Open-Source Music Player',
  description:
    'An offline-first, open-source music player with local library management, official online provider resolvers, and Discord-style commands.',
  manifest: '/manifest.webmanifest',
  icons: {
    icon: '/icon.svg',
    apple: '/icon.svg',
  },
  openGraph: {
    title: 'SONORA — Open-Source Music Player',
    description:
      'An offline-first, open-source music player with local library management, official online provider resolvers, and Discord-style commands.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SONORA — Open-Source Music Player',
    description:
      'An offline-first, open-source music player with local library management, official online provider resolvers, and Discord-style commands.',
  },
};

export const viewport: Viewport = {
  themeColor: '#F5F2E8',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased bg-[#F5F2E8] text-[#20252D] min-h-screen selection:bg-[#354BCB] selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
