# SONORA — Open-Source Offline-First Music Player

SONORA is a modern, open-source, offline-first personal music player built for desktop and mobile web. It combines local audio file import with persistent IndexedDB storage, official online provider resolvers, and Discord-style slash commands (`/play`, `/add`, `/pause`, `/skip`).

## Key Principles & Features

1. **No Accounts, No Login, No Passwords**:
   - 100% public, personal client-side app.
   - All audio files and metadata remain strictly inside your browser's local IndexedDB.
   - Zero remote tracking, zero telemetry, zero audio uploads.

2. **Offline-First Music Library**:
   - Multi-file and entire folder audio import.
   - Real browser metadata parser extracting ID3v2/ID3v1 tags, album artwork blobs, and precise track duration.
   - Organize tracks into custom playlists, favorite songs, search, filter, and sort.
   - Persistent playback across page reloads and network disconnects.

3. **Official Online Resolver**:
   - YouTube: Official IFrame Player API embed for embeddable content.
   - Spotify: Official oEmbed and Spotify Embed widget.
   - MetroList: Honest external link / deep link limitation disclosure without fabricated streaming APIs.
   - Direct audio stream support (.mp3, .wav, .flac, .ogg, .m4a).

4. **Discord-Style Music Commands**:
   - Type `/play <url>` to resolve and play immediately.
   - Type `/add <url>` to append to the play queue.
   - `/pause`, `/resume`, `/skip`, `/back`, `/shuffle`, `/repeat`, `/clear`, `/help`.

5. **PWA & Mobile Ready**:
   - Responsive layout adapting seamlessly from desktop to mobile screens.
   - Web App Manifest (`manifest.webmanifest`) and Service Worker (`sw.js`) for offline app shell caching and installability.

## Technology Stack

- **Framework**: Next.js 15 (App Router) + React 19 + TypeScript
- **Styling**: Tailwind CSS v4 with custom editorial design tokens (`#F5F2E8` canvas, `#354BCB` cobalt, `#F47768` coral, `#F5E94A` lemon, `#B9A6F2` lavender, `#A8E6D8` mint)
- **Icons**: Lucide React
- **Storage**: Browser IndexedDB (`sonora_music_db`)
- **Audio Engine**: Native `HTMLAudioElement` + Web Audio + MediaSession API

## Running Locally

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Run unit tests
npx tsx --test lib/commandParser.test.ts lib/resolver.test.ts lib/metadataParser.test.ts

# Build for production
npm run build
```

## License

MIT License. See [LICENSE](LICENSE) for details.
